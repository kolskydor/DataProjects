## Machine Learning Project Part1
#Bar Hazan 305794976 , Dor Kolsky 205687593
#Neccesary Packages For The Whole Packages:
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

########## PART A #########



# Loading the Dataset - Training Dataset
XYtrain = pd.read_csv('C:/Users/kolsk/PycharmProjects/MachineLearningPartA/XY_train.csv')
#print(XYtrain.count)   #Count the number of samples in the Dataset



# Counting The Nulls :
#CountNulls = XYtrain.isnull().sum().sum()
#print(CountNulls)


#################### EDA #############

# Catgorial Variables :

#Title:
#print(XYtrain.title.value_counts())
"""
#Published At:
XYtrain["publishedAt"] = XYtrain["publishedAt"].astype("datetime64")
publishedDates = XYtrain['publishedAt'].dt.strftime('%Y-%m')
publishedDates = sorted(publishedDates)
plt.hist(publishedDates, bins = 30 )
plt.title("Published Year&Month Histogram", fontsize=20)
plt.xlabel("Year&Month Count", fontsize = 15)
plt.ylabel('Frequency', fontsize=15)
plt.show()
"""

#Chanel ID & Title:
#print(XYtrain.channelId.value_counts())
#print(XYtrain.channelTitle.value_counts())

"""
#Category ID :
XYtrain = XYtrain.dropna(subset = ['categoryId'])
XYtrain['categoryId'] = XYtrain['categoryId'].astype(int)
labels = XYtrain['categoryId'].astype('category').cat.categories.tolist()
counts = XYtrain['categoryId'].value_counts()
sizes = [counts[var_cat] for var_cat in labels]
fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels=labels, autopct='%1.1f%%', shadow=True) #autopct is show the % on plot
ax1.axis('equal')
plt.title("CategoryId PieChart", fontsize=20)
plt.show()
"""

"""
#Trending Year&Month
XYtrain["trending_date"] = XYtrain["trending_date"].astype("datetime64")
TrendingDates = XYtrain['trending_date'].dt.strftime('%Y-%m')
TrendingDates = sorted(TrendingDates)
plt.hist(TrendingDates, bins = 30 )
plt.title("Trending Year&Month Histogram", fontsize=20)
plt.xlabel("Year&Month Count", fontsize = 15)
plt.ylabel('Frequency', fontsize=15)
plt.show()
"""

#Tags:
#print(XYtrain.tags.value_counts())

"""
#Numerical Variables:
# 1.View count
#Boxplot
plt.boxplot(XYtrain['view_count'])
plt.title("View Count Boxplot", fontsize=20)
plt.show()
#Histogram:
plt.hist(XYtrain['view_count'] , bins = 30 )
plt.title("View Count Histogram", fontsize=20)
plt.xlabel("View Count", fontsize = 15)
plt.ylabel('Frequency', fontsize=15)
plt.show()
"""

"""
#2.Likes
#Boxplot :
LikeswithoutNulls = XYtrain['likes'].dropna(how='any',axis=0)
plt.boxplot(LikeswithoutNulls)
plt.title("Likes Boxplot", fontsize=20)
plt.show()
#Histogram:
plt.hist(XYtrain['likes'], bins = 30 )
plt.title("Likes Histogram", fontsize=20)
plt.xlabel("Likes Count", fontsize = 15)
plt.ylabel('Frequency', fontsize=15)
plt.show()
"""

"""
#3.Dislikes :
#Boxplot :
plt.boxplot(XYtrain['dislikes'])
plt.title("Dislikes Boxplot", fontsize=20)
plt.show()
#Histogram:
plt.hist(XYtrain['dislikes'], bins = 30 )
plt.title("Dislikes Histogram", fontsize=20)
plt.xlabel("Dislikes Count", fontsize = 15)
plt.ylabel('Frequency', fontsize=15)
plt.show()
"""

"""
#3.Comments :
#Boxplot :
plt.boxplot(XYtrain['comment_count'])
plt.title("Comments Boxplot", fontsize=20)
plt.show()
#Histogram:
plt.hist(XYtrain['comment_count'], bins = 30 )
plt.title("Comments Histogram", fontsize=20)
plt.xlabel("Comments Count", fontsize = 15)
plt.ylabel('Frequency', fontsize=15)
plt.show()
"""


###################PreProcess###########################
# 1. Nulls Handeling:
# Create the Dataset Without Nulls:
#print(XYtrain.isna().sum())

# Removing Nulls from Likes and CatagoryID
XYtrain = XYtrain.dropna(subset=['likes'])
XYtrain = XYtrain.dropna(subset=['categoryId'])
#print(XYtrain.isna().sum())

"""
# 2.Counting Outliers :
Q1 = XYtrain[['view_count', 'likes', 'dislikes', 'comment_count']].quantile(0.25)
Q3 = XYtrain[['view_count', 'likes', 'dislikes', 'comment_count']].quantile(0.75)
IQR = Q3 - Q1
CountOutliers = ((XYtrain[['view_count', 'likes', 'dislikes', 'comment_count']] < (Q1 - 1.5 * IQR)) | (
            XYtrain[['view_count', 'likes', 'dislikes', 'comment_count']] > (Q3 + 1.5 * IQR))).sum()
print(CountOutliers)
"""


# 3. #Checking For Duplicates:
#XYtrain.duplicated(subset=None, keep='first')


#########  Segmentation :      #########

# Make Segments of the tags by the char of "|| and afterwards Making TagsCount Feature from the original tags :
XYtrain['tags_count'] = 0
for i in XYtrain.index:
    counter = 0
    origin = XYtrain.loc[i, 'tags']
    if origin == '[None]':
        XYtrain.loc[i, 'tags_count'] = 0
    for j in range(0, len(origin)):
        if origin[j] == '|':
            counter += 1
    if counter == 0:
        XYtrain.loc[i, 'tags_count'] = 1
    else:
        XYtrain.loc[i, 'tags_count'] = counter



########## Feature Extraction : ##############
# PublishedAt:
XYtrain["publishedAt"] = XYtrain["publishedAt"].astype("datetime64")
XYtrain['PublishedSeason'] = XYtrain['publishedAt'].dt.strftime('%m')
for i in XYtrain.index:
    if ((XYtrain.loc[i, 'PublishedSeason'] == '01') | (XYtrain.loc[i, 'PublishedSeason'] == '02') | (
            XYtrain.loc[i, 'PublishedSeason'] == '03')):
        XYtrain.loc[i, 'PublishedSeason'] = 'winter'
    elif ((XYtrain.loc[i, 'PublishedSeason'] == '04') | (XYtrain.loc[i, 'PublishedSeason'] == '05') | (
            XYtrain.loc[i, 'PublishedSeason'] == '06')):
        XYtrain.loc[i, 'PublishedSeason'] = 'spring'
    elif ((XYtrain.loc[i, 'PublishedSeason'] == '07') | (XYtrain.loc[i, 'PublishedSeason'] == '08') | (
            XYtrain.loc[i, 'PublishedSeason'] == '09')):
        XYtrain.loc[i, 'PublishedSeason'] = 'summer'
    else:
        XYtrain.loc[i, 'PublishedSeason'] = 'autumn'


# Counting the Title's chars
def charCount(origin, res):
    for i in XYtrain.index:
        XYtrain.loc[i, res] = len(XYtrain.loc[i, origin])


XYtrain['title_char_count'] = 0
charCount('title', 'title_char_count')




#Airtime :
XYtrain["publishedAt"] = XYtrain["publishedAt"].astype("datetime64")
XYtrain["trending_date"] = XYtrain["trending_date"].astype("datetime64")
XYtrain['Airtime']= XYtrain["trending_date"] - XYtrain["publishedAt"]
XYtrain['Airtime'] = XYtrain['Airtime'].astype('timedelta64[m]')



#CatagoryLevel:
def categoryCount(categoryId):
    categoryCount = (XYtrain['categoryId'] == categoryId).sum()
    return categoryCount


XYtrain['category_ratio'] = 0
numOfSamples = len(XYtrain)


for i in XYtrain.index:
    category_Count = categoryCount(XYtrain.loc[i, 'categoryId'])
    category_ratio = category_Count / numOfSamples
    XYtrain.loc[i, 'category_ratio'] = category_ratio


quan34 = np.quantile(XYtrain['category_ratio'], 0.34)
quan66 = np.quantile(XYtrain['category_ratio'], 0.66)

for i in XYtrain.index:
    if XYtrain.loc[i, 'category_ratio'] < quan34:
        XYtrain.loc[i, 'category_ratio'] = 'Low'
    elif XYtrain.loc[i, 'category_ratio'] > quan66:
        XYtrain.loc[i, 'category_ratio'] = 'Medium'
    else:
        XYtrain.loc[i, 'category_ratio'] = 'High'


###### Feature Representation : #######
# No Normalize Or Dummy Variables was Made yet.




"""
###### Feature Selection : #######

# Qualtative :
# Scatter Plots:
#View Counts - Comments
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['comment_count'] )
plt.title("View Count vs Comment Count ")
plt.xlabel("Comments")
plt.ylabel("View Count")
plt.show()

#View Counts - DisLikes
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['dislikes'] )
plt.title("View Count vs Dislikes ")
plt.xlabel("Dislikes")
plt.ylabel("View Count")
plt.show()


#View Counts - Likes
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['likes'] )
plt.title("View Count vs Likes ")
plt.xlabel("Likes")
plt.ylabel("View Count")
plt.show()

# View Counts - Title Char Count
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['title_char_count'] )
plt.title("View Count vs Title Char Count ")
plt.ylabel("View Count")
plt.xlabel("title_char_count")
plt.show()


# View Counts - Tags Count
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['tags_count'] )
plt.title("View Count vs Tags count ")
plt.ylabel("View Count")
plt.xlabel("Tags count")
plt.show()

# View Counts - Published Season
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['PublishedSeason'] )
plt.title("View Count vs PublishedSeason ")
plt.ylabel("View Count")
plt.xlabel("PublishedSeason")
plt.show()

# View Counts - CategoryRatio
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['category_ratio'] )
plt.title("View Count vs category_ratio ")
plt.ylabel("View Count")
plt.xlabel("category_ratio")
plt.show()

# View Counts - Airtime
plt.scatter(y=XYtrain['view_count'] , x=XYtrain['Airtime'] )
plt.title("View Count vs Airtime ")
plt.ylabel("View Count")
plt.xlabel("Airtime")
plt.show()

import seaborn as sns
#Correlation Matrix:
XYtrain['categoryId'] = XYtrain['categoryId'].astype(object)
corrMatrixPears = XYtrain.corr()
sns.heatmap(corrMatrixPears, annot=True)
plt.title("Correlation Matrix", fontsize=20)
plt.show()

"""



"""
import statsmodels.api as sm
# Quantitive: - Stepwise Regression :
x = XYtrain[["comment_count", "dislikes", "likes", "tags_count", "title_char_count", 'PublishedSeason','Airtime','category_ratio']]
y = XYtrain["view_count"]
x = pd.get_dummies(x, columns=["PublishedSeason",'category_ratio'])


def get_stats():
    results = sm.OLS(y, x).fit()
    return results


StepWiseSelectionStats = get_stats()

x = XYtrain[["comment_count", "dislikes", "likes", "title_char_count", 'tags_count', 'Airtime','category_ratio']]
x = pd.get_dummies(x, columns=['category_ratio'])
StepWiseSelectionStats= get_stats()


x = XYtrain[["comment_count", "dislikes", "likes", "title_char_count",'Airtime','category_ratio']]
x = pd.get_dummies(x, columns=['category_ratio'])
StepWiseSelectionStats= get_stats()


######### Dimensionality Reduction ##############
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
pca = PCA(n_components=2)
x = StandardScaler().fit_transform(x)
principalComponents = pca.fit_transform(x)
principalDf = pd.DataFrame(data=principalComponents
                           , columns=['principal component 1', 'principal component 2'])


"""

XYtrain.to_csv("PartAFinal.csv")
